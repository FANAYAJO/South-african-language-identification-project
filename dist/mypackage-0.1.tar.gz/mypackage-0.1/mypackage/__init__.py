from . import myModule
